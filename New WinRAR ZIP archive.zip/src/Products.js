export const Products = [
  {
    _id: 1,
    name: "Product 1",
    image: "https://dummyimage.com/300x300/000/fff",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    brand: "Brand 1",
    category: "Category 1",
    price: 10.99,
    countInStock: 0,
    rating: 4.5,
    version: "1.0"
  },
  {
    _id: 2,
    name: "Product 2",
    image: "https://dummyimage.com/300x300/000/fff",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    brand: "Brand 2",
    category: "Category 2",
    price: 19.99,
    countInStock: 5,
    rating: 3.8,
    version: "1.1"
  },
  {
    _id: 3,
    name: "Product 3",
    image: "https://dummyimage.com/300x300/000/fff",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    brand: "Brand 3",
    category: "Category 3",
    price: 14.99,
    countInStock: 3,
    rating: 4.2,
    version: "2.0"
  },
  {
    _id: 4,
    name: "Product 4",
    image: "https://dummyimage.com/300x300/000/fff",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    brand: "Brand 1",
    category: "Category 2",
    price: 8.99,
    countInStock: 0,
    rating: .5,
    version: "1.2"
  },
    {
      _id: 11,
      name: "Product 1",
      image: "https://dummyimage.com/300x300/000/fff",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      brand: "Brand 1",
      category: "Category 1",
      price: 10.99,
      countInStock: 10,
      rating: 4.5,
      version: "1.0"
    },
    {
      _id: 12,
      name: "Product 2",
      image: "https://dummyimage.com/300x300/000/fff",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      brand: "Brand 2",
      category: "Category 2",
      price: 19.99,
      countInStock: 5,
      rating: 3.8,
      version: "1.1"
    },
    {
      _id: 13,
      name: "Product 3",
      image: "https://dummyimage.com/300x300/000/fff",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      brand: "Brand 3",
      category: "Category 3",
      price: 14.99,
      countInStock: 3,
      rating: 4.2,
      version: "2.0"
    },
    {
      _id: 14,
      name: "Product 4",
      image: "https://dummyimage.com/300x300/000/fff",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
      brand: "Brand 1",
      category: "Category 2",
      price: 8.99,
      countInStock: 0,
      rating: .5,
      version: "1.2"
    }
  ];
  